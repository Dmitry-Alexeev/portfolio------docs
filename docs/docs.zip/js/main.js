$(document).ready(function() {

	/* Call plugins hrere ...*/

	
});